# Resonance — Android starter project

Private local music player. No account, backend, ads, or automatic scan of all device music.

## Included in milestone 0.1.0
- Kotlin + Jetpack Compose app shell
- Explicit multi-file audio import through Android's document picker
- Basic local library list for the current app session
- Media3 / ExoPlayer playback foundation
- First-pass Ambient Glow visual treatment
- DSP domain model for future parametric EQ profiles
- MediaSessionService scaffold

## Important status
This is a starter implementation, not a finished player. The custom DSP model is not yet connected to the Media3 audio sink. Library persistence, tag editing, lyrics, playlists, presets, ReplayGain, crossfade, visualizer and full background/controller integration are not yet implemented. The initial track list is currently in memory and will not persist across app restarts. Build has not been run in this environment, so open in Android Studio and run Gradle sync/build before installing.

## Open
1. Extract the ZIP and open the `Resonance` folder in Android Studio.
2. Use JDK 17.
3. Allow Gradle to sync (initial sync requires internet).
4. Run on an Android device or emulator.

## Planned milestones
1. Connect a custom Media3 AudioProcessor and implement biquad peaking/shelf/pass filters, preamp, headroom/clipping protection, with DSP tests.
2. Complete MediaSessionService/MediaController integration and verify lock-screen/notification playback.
3. Persist imported files and library state; read/write metadata and artwork where permitted, with app-side overrides as fallback.
4. Add lyrics, playlists, presets, ReplayGain, crossfade, sleep timer and visualizer.
5. Finish dynamic album-color extraction, cached blur, Ambient Glow controls and theme customization.
6. Test sustained playback, seek/track transitions, Bluetooth and screen-off on Snapdragon; maintain stable baseline compatibility on MediaTek.

## Design constraints
- Do not use Android system EQ, Dolby, or OEM effects as the app's EQ implementation.
- DSP must process decoded PCM in the app's audio pipeline.
- Prioritize Snapdragon performance; maintain baseline MediaTek stability without dedicated optimization.
- Only explicitly imported files belong in the app library.
