package dev.resonance.player.dsp

enum class FilterType { PEAKING, LOW_SHELF, HIGH_SHELF, LOW_PASS, HIGH_PASS }

data class EqBand(
    val id: String,
    val type: FilterType = FilterType.PEAKING,
    val frequencyHz: Float = 1000f,
    val gainDb: Float = 0f,
    val q: Float = 0.707f,
    val enabled: Boolean = true
)

data class EqProfile(
    val name: String = "Flat",
    val preampDb: Float = 0f,
    val preventClipping: Boolean = true,
    val bands: List<EqBand> = defaultBands()
)

fun defaultBands() = listOf(
    EqBand("low", frequencyHz = 60f),
    EqBand("low-mid", frequencyHz = 250f),
    EqBand("mid", frequencyHz = 1000f),
    EqBand("high-mid", frequencyHz = 4000f),
    EqBand("high", frequencyHz = 12000f)
)
