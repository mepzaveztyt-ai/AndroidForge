package dev.resonance.player.playback

import android.content.Context
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer

/** Temporary shared player holder for the starter milestone. Service/controller integration follows next. */
object PlayerHolder {
    @Volatile private var instance: ExoPlayer? = null
    fun get(context: Context): ExoPlayer = instance ?: synchronized(this) {
        instance ?: ExoPlayer.Builder(context.applicationContext)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true)
            .build().also { instance = it }
    }
}
