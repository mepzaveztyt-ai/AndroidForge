package dev.resonance.player.playback

import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/** Initial MediaSessionService scaffold; controller integration is the next milestone. */
class PlaybackService : MediaSessionService() {
    private var mediaSession: MediaSession? = null
    override fun onCreate() {
        super.onCreate()
        mediaSession = MediaSession.Builder(this, PlayerHolder.get(this)).build()
    }
    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession
    override fun onDestroy() {
        mediaSession?.release()
        mediaSession = null
        super.onDestroy()
    }
}
