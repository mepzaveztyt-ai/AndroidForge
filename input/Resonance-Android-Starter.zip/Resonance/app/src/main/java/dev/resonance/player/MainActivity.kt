package dev.resonance.player

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import dev.resonance.player.playback.PlayerHolder

private val Ink = Color(0xFF101116)
private val Panel = Color(0xFF1A1C24)
private val Accent = Color(0xFFB7A1FF)
private val TextMuted = Color(0xFF9C9BA8)

data class LocalTrack(val uri: Uri, val displayName: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ResonanceApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class, UnstableApi::class)
@Composable
private fun ResonanceApp() {
    val context = LocalContext.current
    val tracks = remember { mutableStateListOf<LocalTrack>() }
    val player = remember { PlayerHolder.get(context) }
    var isPlaying by remember { mutableStateOf(player.isPlaying) }
    var currentTrack by remember { mutableIntStateOf(0) }
    var showEqInfo by remember { mutableStateOf(false) }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                currentTrack = player.currentMediaItemIndex.coerceAtLeast(0)
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { uri ->
            runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val name = runCatching {
                context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(0) else null
                }
            }.getOrNull() ?: uri.lastPathSegment ?: "Audio file"
            if (tracks.none { it.uri == uri }) tracks.add(LocalTrack(uri, name))
        }
        if (uris.isNotEmpty()) {
            player.setMediaItems(uris.map { MediaItem.fromUri(it) })
            player.prepare()
            player.playWhenReady = false
            currentTrack = 0
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(background = Ink, surface = Panel, primary = Accent, onBackground = Color(0xFFF3F1F8), onSurface = Color(0xFFF3F1F8))) {
        Scaffold(
            containerColor = Ink,
            topBar = {
                TopAppBar(
                    title = { Column { Text("Resonance", fontWeight = FontWeight.Bold, fontSize = 23.sp); Text("YOUR MUSIC. YOUR SOUND.", color = TextMuted, fontSize = 10.sp, letterSpacing = 2.sp) } },
                    actions = { IconButton(onClick = { showEqInfo = true }) { Icon(Icons.Default.Equalizer, contentDescription = "Эквалайзер", tint = Accent) } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink)
                )
            },
            floatingActionButton = {
                ExtendedFloatingActionButton(onClick = { importPicker.launch(arrayOf("audio/*")) }, containerColor = Accent, contentColor = Ink,
                    icon = { Icon(Icons.Default.Add, contentDescription = null) }, text = { Text("Добавить музыку", fontWeight = FontWeight.SemiBold) })
            }
        ) { padding ->
            LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 110.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Box(Modifier.fillMaxWidth().height(210.dp), contentAlignment = Alignment.Center) {
                        Box(Modifier.size(190.dp).blur(42.dp).background(Brush.radialGradient(listOf(Accent.copy(alpha = .42f), Color(0xFF4C70B8).copy(alpha = .15f), Color.Transparent)), RoundedCornerShape(40.dp)))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(124.dp).background(Brush.linearGradient(listOf(Color(0xFF3A344B), Color(0xFF222A3D))), RoundedCornerShape(24.dp)), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.MusicNote, contentDescription = null, tint = Accent, modifier = Modifier.size(56.dp))
                            }
                            Spacer(Modifier.height(12.dp))
                            Text(if (tracks.isEmpty()) "Твоя музыка — здесь" else "Локальная библиотека", fontWeight = FontWeight.SemiBold)
                            Text("Только файлы, которые ты добавил", color = TextMuted, fontSize = 12.sp)
                        }
                    }
                }
                item { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text("БИБЛИОТЕКА", color = TextMuted, fontSize = 11.sp, letterSpacing = 2.sp, modifier = Modifier.weight(1f)); Text("${tracks.size} трек(ов)", color = TextMuted, fontSize = 12.sp) } }
                if (tracks.isEmpty()) {
                    item {
                        Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Add, contentDescription = null, tint = Accent, modifier = Modifier.size(28.dp))
                                Spacer(Modifier.height(8.dp)); Text("Добавь первые аудиофайлы", fontWeight = FontWeight.Medium)
                                Text("Resonance не сканирует всю память автоматически.", color = TextMuted, fontSize = 12.sp)
                            }
                        }
                    }
                } else {
                    items(tracks, key = { it.uri.toString() }) { track ->
                        Surface(color = Panel, shape = RoundedCornerShape(16.dp), onClick = {
                            val index = tracks.indexOf(track)
                            if (index >= 0) { player.setMediaItems(tracks.map { MediaItem.fromUri(it.uri) }, index, 0L); player.prepare(); player.play(); currentTrack = index }
                        }, modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(44.dp).background(Color(0xFF292634), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, contentDescription = null, tint = Accent) }
                                Spacer(Modifier.width(12.dp)); Text(track.displayName, modifier = Modifier.weight(1f), maxLines = 2, fontWeight = FontWeight.Medium)
                                if (currentTrack == tracks.indexOf(track) && isPlaying) Icon(Icons.Default.PlayArrow, contentDescription = "Сейчас играет", tint = Accent)
                            }
                        }
                    }
                }
                item {
                    Surface(color = Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Column(Modifier.weight(1f)) { Text("Сейчас играет", color = TextMuted, fontSize = 11.sp); Text(tracks.getOrNull(currentTrack)?.displayName ?: "Ничего не выбрано", maxLines = 1, fontWeight = FontWeight.SemiBold) }
                            IconButton(onClick = { if (isPlaying) player.pause() else if (player.mediaItemCount > 0) player.play() }) {
                                Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = if (isPlaying) "Пауза" else "Воспроизвести", tint = Accent, modifier = Modifier.size(32.dp))
                            }
                        }
                    }
                }
            }
        }
        if (showEqInfo) AlertDialog(onDismissRequest = { showEqInfo = false }, title = { Text("Собственный эквалайзер") },
            text = { Text("Следующий этап — подключить собственный DSP к аудиотракту Media3 и проверить реальную обработку PCM. Системный эквалайзер и Dolby не используются вместо нашего DSP.") },
            confirmButton = { TextButton(onClick = { showEqInfo = false }) { Text("Понятно") } }, containerColor = Panel)
    }
}
